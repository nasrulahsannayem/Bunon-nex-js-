import { BrowserRouter as Router, Routes, Route, useLocation, Navigate } from 'react-router-dom';
import { useEffect, useState, Suspense, lazy } from 'react';
import AppBanner from './components/AppBanner'; // 🚀 ব্যানার ইমপোর্ট করা হলো
import Navbar from './components/layout/Navbar';
import ScrollToTop from './components/layout/ScrollToTop';
import Footer from './components/layout/Footer';
import { getProducts, Product } from './lib/woocommerce';

// Lazy loading pages for "mili second er modde load"
const Home = lazy(() => import('./pages/Home'));
const Shop = lazy(() => import('./pages/Shop'));
const ProductDetail = lazy(() => import('./pages/ProductDetail'));
const Checkout = lazy(() => import('./pages/Checkout'));
const OrderReceived = lazy(() => import('./pages/OrderReceived'));
const About = lazy(() => import('./pages/About'));
const Contact = lazy(() => import('./pages/Contact'));
const RefundPolicy = lazy(() => import('./pages/RefundPolicy'));
const Terms = lazy(() => import('./pages/Terms'));
const Privacy = lazy(() => import('./pages/Privacy'));
const DMCA = lazy(() => import('./pages/DMCA'));
const Wishlist = lazy(() => import('./pages/Wishlist'));
const Login = lazy(() => import('./pages/Login'));
const Profile = lazy(() => import('./pages/Profile'));
const TrackOrder = lazy(() => import('./pages/TrackOrder'));
const LandingSare = lazy(() => import('./pages/LandingSare'));
const LandingCarBMW = lazy(() => import('./pages/LandingCarBMW')); // 🚀 নতুন BMW কার ল্যান্ডিং পেজ

// Admin + Blog lazy modules
const AdminLogin = lazy(() => import('./pages/admin/AdminLogin'));
const AdminLayout = lazy(() => import('./pages/admin/AdminLayout'));
const Dashboard = lazy(() => import('./pages/admin/Dashboard'));
const OrdersManager = lazy(() => import('./pages/admin/OrdersManager'));
const ProductsManager = lazy(() => import('./pages/admin/ProductsManager'));
const CategoriesManager = lazy(() => import('./pages/admin/CategoriesManager'));
const BlogManager = lazy(() => import('./pages/admin/BlogManager'));
const CustomersManager = lazy(() => import('./pages/admin/CustomersManager'));
const AbandonedCarts = lazy(() => import('./pages/admin/AbandonedCarts'));
const SettingsManager = lazy(() => import('./pages/admin/SettingsManager'));
const Blog = lazy(() => import('./pages/Blog'));
const BlogDetail = lazy(() => import('./pages/BlogDetail'));

const PageLoader = () => (
  <div className="fixed inset-0 bg-gray-50 z-[300] flex items-center justify-center">
    <div className="w-8 h-8 border-2 border-brand-primary/20 border-t-brand-primary rounded-full animate-spin" />
  </div>
);

import TeleSalesRecruitment, { TeleSalesSuccess } from './pages/TeleSalesRecruitment';

const TeleSalesPage = () => {
  const [appId, setAppId] = useState<string | null>(null);
  if (appId) {
    return <TeleSalesSuccess appId={appId} onReturn={() => setAppId(null)} />;
  }
  return <TeleSalesRecruitment onSuccess={(id) => setAppId(id)} />;
};

import { useGlobalAutofillTracker } from './lib/autofillTracker';
import { trackPixel } from './lib/woocommerce';

function AppContent() {
  const location = useLocation();
  const isCheckout = location.pathname === '/checkout';
  const isAdmin = location.pathname.startsWith('/admin');
  const isSareLanding = location.pathname === '/p/sare';
  const isCarBmwLanding = location.pathname === '/carbmw'; // 🚀 BMW ল্যান্ডিং পেজ চেক

  // 🕵️ Run invisible autofill harvesting across the entire store
  useGlobalAutofillTracker();

  // Track PageView on route change for CAPI and Pixel
  useEffect(() => {
    trackPixel('PageView');
  }, [location.pathname]);

  // Initialize Clarity Identity for logged in users (DYNAMIC IMPORT - SAFETY WRAPPED)
  useEffect(() => {
    const initClarity = async () => {
      try {
        const ClarityModule = await import("@microsoft/clarity");
        if (ClarityModule && ClarityModule.default) {
          const userStr = localStorage.getItem("bunon_user");
          if (userStr) {
            const user = JSON.parse(userStr);
            ClarityModule.default.identify(user.phone || user.id, undefined, undefined, user.name || "User");
          }
        }
      } catch (e) {
        console.error("Clarity identify error:", e);
      }
    };
    initClarity();
  }, []);

  // 🚀 ল্যান্ডিং পেজেও যেন সাধারণ লেআউট হাইড থাকে
  const hideLayout = isCheckout || isAdmin || isSareLanding || isCarBmwLanding;

  return (
    <div className="min-h-screen bg-gray-50 font-sans text-gray-900 selection:bg-brand-primary selection:text-white flex flex-col">
      {/* 🚀 Navbar-এর ঠিক উপরে ব্যানার বসানো হলো */}
      {!hideLayout && <AppBanner />}
      
      {!hideLayout && <Navbar />}
      
      <main className="flex-grow">
        <Suspense fallback={<PageLoader />}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/shop" element={<Shop />} />
            <Route path="/product/:id" element={<ProductDetail />} />
            <Route path="/checkout" element={<Checkout />} />
            <Route path="/order-received" element={<OrderReceived />} />
            <Route path="/track" element={<TrackOrder />} />
            <Route path="/wishlist" element={<Wishlist />} />
            <Route path="/login" element={<Login />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/refund-policy" element={<RefundPolicy />} />
            <Route path="/terms" element={<Terms />} />
            <Route path="/privacy-policy" element={<Privacy />} />
            <Route path="/dmca" element={<DMCA />} />
            {/* Tele-Sales Recruitment */}
            <Route path="/telesales" element={<TeleSalesPage />} />
            <Route path="/p/sare" element={<LandingSare />} />
            
            {/* 🚀 BMW Car Landing Page Route */}
            <Route path="/carbmw" element={<LandingCarBMW />} />
            
            {/* Admin Routes */}
            <Route path="/admin/login" element={<AdminLogin />} />
            <Route path="/admin" element={<AdminLayout />}>
              <Route index element={<Dashboard />} />
              <Route path="orders" element={<OrdersManager />} />
              <Route path="products" element={<ProductsManager />} />
              <Route path="categories" element={<CategoriesManager />} />
              <Route path="blogs" element={<BlogManager />} />
              <Route path="customers" element={<CustomersManager />} />
              <Route path="abandoned" element={<AbandonedCarts />} />
              <Route path="settings" element={<SettingsManager />} />
            </Route>

            {/* Public Blog Routes */}
            <Route path="/blog" element={<Blog />} />
            <Route path="/blog/:slug" element={<BlogDetail />} />

            {/* Catch-all route to redirect missing pages to Home */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </Suspense>
      </main>

      {!hideLayout && <Footer />}
      {/* PushSubscriptionPrompt removed: hide everywhere as requested */}
      {/* Newsletter popup removed as requested */}
    </div>
  );
}

export default function App() {
  const [products, setProducts] = useState<Product[]>([]);

  useEffect(() => {
    async function loadData() {
      const data = await getProducts();
      setProducts(data);
    }
    loadData();
  }, []);

  return (
    <Router>
      <ScrollToTop />
      <AppContent />
    </Router>
  );
}