import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';

export default function BlogDetail() {
  const { slug } = useParams();
  const [blog, setBlog] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState(false);

  useEffect(() => {
    fetch(`/api/blog/${slug}`).then(r => r.json()).then(d => {
      if (d.ok) setBlog(d.blog); else setErr(true);
      setLoading(false);
    });
  }, [slug]);

  if (loading) return <div className="max-w-3xl mx-auto px-4 py-10 text-center text-gray-500">লোড হচ্ছে...</div>;
  if (err || !blog) return <div className="max-w-3xl mx-auto px-4 py-10 text-center"><p className="text-gray-500">পোস্টটি পাওয়া যায়নি।</p><Link to="/blog" className="text-brand-primary">← ব্লগে ফিরুন</Link></div>;

  return (
    <div className="max-w-3xl mx-auto px-4 py-10">
      <Link to="/blog" className="text-brand-primary text-sm mb-4 inline-block">← ব্লগে ফিরুন</Link>
      {blog.featured_image && <img src={blog.featured_image} alt={blog.title} className="w-full h-64 object-cover rounded-2xl mb-6" />}
      <h1 className="text-3xl font-black text-brand-navy mb-2">{blog.title}</h1>
      <p className="text-gray-400 text-sm mb-6">{blog.author ? `লেখক: ${blog.author}` : ''} {blog.published_at ? ` • ${blog.published_at.slice(0, 10)}` : ''}</p>
      <article className="prose max-w-none text-gray-700 leading-relaxed whitespace-pre-wrap">{blog.content}</article>
    </div>
  );
}
