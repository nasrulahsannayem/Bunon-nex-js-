import { useEffect, useState } from 'react';
import { Trash2, Edit2, Plus, X } from 'lucide-react';

const API = '/api/admin/categories';
const auth = () => ({ Authorization: `Bearer ${localStorage.getItem('bunon_token')}` });

export default function CategoriesManager() {
  const [cats, setCats] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<any | null>(null);
  const [form, setForm] = useState({ name: '', slug: '', parent_id: '', image: '', description: '', menu_order: '0', status: '1' });

  const load = () => {
    setLoading(true);
    fetch(API, { headers: auth() }).then(r => r.json()).then(d => {
      if (d.ok) setCats(d.categories);
      setLoading(false);
    });
  };
  useEffect(load, []);

  const openAdd = () => { setEditing(null); setForm({ name: '', slug: '', parent_id: '', image: '', description: '', menu_order: '0', status: '1' }); setModalOpen(true); };
  const openEdit = (c: any) => { setEditing(c); setForm({ name: c.name || '', slug: c.slug || '', parent_id: c.parent_id ?? '', image: c.image || '', description: c.description || '', menu_order: String(c.menu_order ?? 0), status: String(c.status ?? 1) }); setModalOpen(true); };

  const save = async () => {
    if (!form.name) return alert('নাম দিন');
    const body = {
      name: form.name, slug: form.slug || undefined,
      parent_id: form.parent_id ? Number(form.parent_id) : null,
      image: form.image || null, description: form.description || null,
      menu_order: Number(form.menu_order), status: Number(form.status)
    };
    const res = editing
      ? await fetch(`${API}/${editing.id}`, { method: 'PUT', headers: { ...auth(), 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
      : await fetch(API, { method: 'POST', headers: { ...auth(), 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const d = await res.json();
    if (d.ok) { setModalOpen(false); load(); } else alert(d.msg || 'ত্রুটি');
  };

  const del = async (id: number) => {
    if (!confirm('ডিলিট করবেন?')) return;
    const res = await fetch(`${API}/${id}`, { method: 'DELETE', headers: auth() });
    const d = await res.json();
    if (d.ok) load(); else alert(d.msg || 'ত্রুটি');
  };

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-2xl font-bold text-brand-navy">ক্যাটাগরি ম্যানেজমেন্ট</h1>
        <button onClick={openAdd} className="flex items-center gap-2 bg-brand-primary text-white px-4 py-2 rounded-xl">
          <Plus size={18} /> নতুন ক্যাটাগরি
        </button>
      </div>

      {loading ? <p className="text-gray-500">লোড হচ্ছে...</p> : (
        <div className="bg-white rounded-xl shadow overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 text-gray-600">
              <tr><th className="p-3 text-left">#</th><th className="p-3 text-left">নাম</th><th className="p-3 text-left">স্লাগ</th><th className="p-3 text-left">অবস্থা</th><th className="p-3 text-left">অ্যাকশন</th></tr>
            </thead>
            <tbody>
              {cats.map(c => (
                <tr key={c.id} className="border-t">
                  <td className="p-3">{c.id}</td>
                  <td className="p-3 font-medium">{c.name}</td>
                  <td className="p-3 text-gray-500">{c.slug}</td>
                  <td className="p-3">{c.status ? 'সক্রিয়' : 'নিষ্ক্রিয়'}</td>
                  <td className="p-3 flex gap-2">
                    <button onClick={() => openEdit(c)} className="text-blue-600"><Edit2 size={16} /></button>
                    <button onClick={() => del(c.id)} className="text-red-600"><Trash2 size={16} /></button>
                  </td>
                </tr>
              ))}
              {cats.length === 0 && <tr><td colSpan={5} className="p-4 text-center text-gray-400">কোনো ক্যাটাগরি নাই</td></tr>}
            </tbody>
          </table>
        </div>
      )}

      {modalOpen && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg p-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-bold">{editing ? 'এডিট' : 'নতুন'} ক্যাটাগরি</h2>
              <button onClick={() => setModalOpen(false)}><X size={20} /></button>
            </div>
            <div className="space-y-3">
              <input className="w-full border rounded-lg p-2" placeholder="নাম *" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />
              <input className="w-full border rounded-lg p-2" placeholder="স্লাগ (খালি রাখলে অটো)" value={form.slug} onChange={e => setForm({ ...form, slug: e.target.value })} />
              <input className="w-full border rounded-lg p-2" placeholder="প্যারেন্ট আইডি (খালি = টপ)" value={form.parent_id} onChange={e => setForm({ ...form, parent_id: e.target.value })} />
              <input className="w-full border rounded-lg p-2" placeholder="ইমেজ URL" value={form.image} onChange={e => setForm({ ...form, image: e.target.value })} />
              <textarea className="w-full border rounded-lg p-2" placeholder="বিবরণ" rows={3} value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} />
              <div className="flex gap-3">
                <input className="w-1/2 border rounded-lg p-2" placeholder="মেনু অর্ডার" value={form.menu_order} onChange={e => setForm({ ...form, menu_order: e.target.value })} />
                <select className="w-1/2 border rounded-lg p-2" value={form.status} onChange={e => setForm({ ...form, status: e.target.value })}>
                  <option value="1">সক্রিয়</option><option value="0">নিষ্ক্রিয়</option>
                </select>
              </div>
            </div>
            <button onClick={save} className="mt-4 w-full bg-brand-primary text-white py-2 rounded-xl">সেভ করুন</button>
          </div>
        </div>
      )}
    </div>
  );
}
