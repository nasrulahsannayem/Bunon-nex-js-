export default function ProductsManager() {
  return <div className="p-6"><h1 className="text-2xl font-bold text-brand-navy mb-4">প্রোডাক্ট ম্যানেজমেন্ট</h1><div className="bg-white rounded-xl shadow p-6 text-gray-500">নির্মাণাধীন — শীঘ্রই আসছে।</div></div>;
}
