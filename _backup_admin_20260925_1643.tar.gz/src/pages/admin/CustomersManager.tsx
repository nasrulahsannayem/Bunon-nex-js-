export default function CustomersManager() {
  return <div className="p-6"><h1 className="text-2xl font-bold text-brand-navy mb-4">কাস্টমার ম্যানেজমেন্ট</h1><div className="bg-white rounded-xl shadow p-6 text-gray-500">নির্মাণাধীন — শীঘ্রই আসছে।</div></div>;
}
