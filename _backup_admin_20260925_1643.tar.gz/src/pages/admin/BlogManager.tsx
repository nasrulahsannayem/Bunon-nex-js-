import { useEffect, useState } from 'react';
import { Trash2, Edit2, Plus, X } from 'lucide-react';

const API = '/api/admin/blogs';
const auth = () => ({ Authorization: `Bearer ${localStorage.getItem('bunon_token')}` });

export default function BlogManager() {
  const [blogs, setBlogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<any | null>(null);
  const [form, setForm] = useState({ title: '', slug: '', excerpt: '', content: '', featured_image: '', author: '', tags: '', status: '0', published_at: '' });

  const load = () => {
    setLoading(true);
    fetch(API, { headers: auth() }).then(r => r.json()).then(d => {
      if (d.ok) setBlogs(d.blogs);
      setLoading(false);
    });
  };
  useEffect(load, []);

  const openAdd = () => { setEditing(null); setForm({ title: '', slug: '', excerpt: '', content: '', featured_image: '', author: '', tags: '', status: '0', published_at: '' }); setModalOpen(true); };
  const openEdit = (b: any) => { setEditing(b); setForm({ title: b.title || '', slug: b.slug || '', excerpt: b.excerpt || '', content: b.content || '', featured_image: b.featured_image || '', author: b.author || '', tags: typeof b.tags === 'string' ? b.tags : (b.tags ? JSON.stringify(b.tags) : ''), status: String(b.status ?? 0), published_at: b.published_at ? b.published_at.slice(0, 16) : '' }); setModalOpen(true); };

  const save = async () => {
    if (!form.title) return alert('টাইটেল দিন');
    const body = {
      title: form.title, slug: form.slug || undefined, excerpt: form.excerpt || null,
      content: form.content || null, featured_image: form.featured_image || null, author: form.author || null,
      tags: form.tags || null, status: Number(form.status),
      published_at: form.status === '1' ? (form.published_at || new Date().toISOString().slice(0, 19).replace('T', ' ')) : null
    };
    const res = editing
      ? await fetch(`${API}/${editing.id}`, { method: 'PUT', headers: { ...auth(), 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
      : await fetch(API, { method: 'POST', headers: { ...auth(), 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const d = await res.json();
    if (d.ok) { setModalOpen(false); load(); } else alert(d.msg || 'ত্রুটি');
  };

  const del = async (id: number) => {
    if (!confirm('ডিলিট করবেন?')) return;
    const res = await fetch(`${API}/${id}`, { method: 'DELETE', headers: auth() });
    const d = await res.json();
    if (d.ok) load(); else alert(d.msg || 'ত্রুটি');
  };

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-2xl font-bold text-brand-navy">ব্লগ ম্যানেজমেন্ট</h1>
        <button onClick={openAdd} className="flex items-center gap-2 bg-brand-primary text-white px-4 py-2 rounded-xl">
          <Plus size={18} /> নতুন পোস্ট
        </button>
      </div>

      {loading ? <p className="text-gray-500">লোড হচ্ছে...</p> : (
        <div className="bg-white rounded-xl shadow overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 text-gray-600">
              <tr><th className="p-3 text-left">#</th><th className="p-3 text-left">টাইটেল</th><th className="p-3 text-left">স্লাগ</th><th className="p-3 text-left">অবস্থা</th><th className="p-3 text-left">অ্যাকশন</th></tr>
            </thead>
            <tbody>
              {blogs.map(b => (
                <tr key={b.id} className="border-t">
                  <td className="p-3">{b.id}</td>
                  <td className="p-3 font-medium">{b.title}</td>
                  <td className="p-3 text-gray-500">{b.slug}</td>
                  <td className="p-3">{b.status ? 'প্রকাশিত' : 'ড্রাফট'}</td>
                  <td className="p-3 flex gap-2">
                    <button onClick={() => openEdit(b)} className="text-blue-600"><Edit2 size={16} /></button>
                    <button onClick={() => del(b.id)} className="text-red-600"><Trash2 size={16} /></button>
                  </td>
                </tr>
              ))}
              {blogs.length === 0 && <tr><td colSpan={5} className="p-4 text-center text-gray-400">কোনো পোস্ট নাই</td></tr>}
            </tbody>
          </table>
        </div>
      )}

      {modalOpen && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-2xl p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-bold">{editing ? 'এডিট' : 'নতুন'} পোস্ট</h2>
              <button onClick={() => setModalOpen(false)}><X size={20} /></button>
            </div>
            <div className="space-y-3">
              <input className="w-full border rounded-lg p-2" placeholder="টাইটেল *" value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} />
              <input className="w-full border rounded-lg p-2" placeholder="স্লাগ (খালি = অটো)" value={form.slug} onChange={e => setForm({ ...form, slug: e.target.value })} />
              <input className="w-full border rounded-lg p-2" placeholder="এক্সার্পট / সংক্ষিপ্ত" value={form.excerpt} onChange={e => setForm({ ...form, excerpt: e.target.value })} />
              <input className="w-full border rounded-lg p-2" placeholder="ফিচার্ড ইমেজ URL" value={form.featured_image} onChange={e => setForm({ ...form, featured_image: e.target.value })} />
              <input className="w-full border rounded-lg p-2" placeholder="লেখক" value={form.author} onChange={e => setForm({ ...form, author: e.target.value })} />
              <input className="w-full border rounded-lg p-2" placeholder="ট্যাগ (কমা দিয়ে)" value={form.tags} onChange={e => setForm({ ...form, tags: e.target.value })} />
              <textarea className="w-full border rounded-lg p-2" placeholder="কন্টেন্ট (পূর্ণ লেখা)" rows={6} value={form.content} onChange={e => setForm({ ...form, content: e.target.value })} />
              <div className="flex gap-3">
                <input className="w-1/2 border rounded-lg p-2" type="datetime-local" value={form.published_at} onChange={e => setForm({ ...form, published_at: e.target.value })} />
                <select className="w-1/2 border rounded-lg p-2" value={form.status} onChange={e => setForm({ ...form, status: e.target.value })}>
                  <option value="0">ড্রাফট</option><option value="1">প্রকাশ করুন</option>
                </select>
              </div>
            </div>
            <button onClick={save} className="mt-4 w-full bg-brand-primary text-white py-2 rounded-xl">সেভ করুন</button>
          </div>
        </div>
      )}
    </div>
  );
}
