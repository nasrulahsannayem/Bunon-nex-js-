import express from 'express';
import { productDbPool } from '../db';

const router = express.Router();

// GET /api/blog - public list (only published)
router.get('/', async (req, res) => {
  try {
    const [rows]: any = await productDbPool.execute(
      `SELECT id, title, slug, excerpt, featured_image, author, tags, published_at
       FROM bunon_blogs WHERE status = 1 ORDER BY published_at DESC, id DESC`
    );
    res.json({ ok: true, blogs: rows });
  } catch (e: any) {
    console.error('[Public Blog] List error:', e.message);
    res.status(500).json({ ok: false, msg: 'Server error' });
  }
});

// GET /api/blog/:slug - public single
router.get('/:slug', async (req, res) => {
  try {
    const [rows]: any = await productDbPool.execute(
      `SELECT id, title, slug, excerpt, content, featured_image, author, tags, published_at
       FROM bunon_blogs WHERE slug = ? AND status = 1 LIMIT 1`,
      [req.params.slug]
    );
    if (!rows.length) return res.status(404).json({ ok: false, msg: 'Not found' });
    res.json({ ok: true, blog: rows[0] });
  } catch (e: any) {
    console.error('[Public Blog] Single error:', e.message);
    res.status(500).json({ ok: false, msg: 'Server error' });
  }
});

export default router;
