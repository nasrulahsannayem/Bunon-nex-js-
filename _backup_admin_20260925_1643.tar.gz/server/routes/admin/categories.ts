import express from 'express';
import { productDbPool } from '../../db';

const router = express.Router();

// GET /api/admin/categories
router.get('/', async (req, res) => {
  try {
    const [rows]: any = await productDbPool.execute(
      `SELECT id, name, slug, parent_id, image, description, menu_order, status, created_at
       FROM bunon_categories ORDER BY menu_order ASC, id DESC`
    );
    res.json({ ok: true, categories: rows });
  } catch (e: any) {
    console.error('[Admin Categories] List error:', e.message);
    res.status(500).json({ ok: false, msg: 'Server error' });
  }
});

// POST /api/admin/categories
router.post('/', async (req, res) => {
  try {
    const { name, slug, parent_id, image, description, menu_order, status } = req.body || {};
    if (!name) return res.status(400).json({ ok: false, msg: 'name required' });
    const finalSlug = (slug || name).toString().toLowerCase().trim()
      .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
    const [r]: any = await productDbPool.execute(
      `INSERT INTO bunon_categories (name, slug, parent_id, image, description, menu_order, status)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [name, finalSlug, parent_id ?? null, image ?? null, description ?? null, menu_order ?? 0, status ?? 1]
    );
    res.json({ ok: true, id: r.insertId });
  } catch (e: any) {
    console.error('[Admin Categories] Create error:', e.message);
    res.status(500).json({ ok: false, msg: 'Server error' });
  }
});

// PUT /api/admin/categories/:id
router.put('/:id', async (req, res) => {
  try {
    const id = req.params.id;
    const { name, slug, parent_id, image, description, menu_order, status } = req.body || {};
    const finalSlug = slug ? slug.toString().toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') : undefined;
    await productDbPool.execute(
      `UPDATE bunon_categories SET
         name = COALESCE(?, name),
         slug = COALESCE(?, slug),
         parent_id = COALESCE(?, parent_id),
         image = COALESCE(?, image),
         description = COALESCE(?, description),
         menu_order = COALESCE(?, menu_order),
         status = COALESCE(?, status)
       WHERE id = ?`,
      [name ?? null, finalSlug ?? null, parent_id ?? null, image ?? null, description ?? null, menu_order ?? null, status ?? null, id]
    );
    res.json({ ok: true });
  } catch (e: any) {
    console.error('[Admin Categories] Update error:', e.message);
    res.status(500).json({ ok: false, msg: 'Server error' });
  }
});

// DELETE /api/admin/categories/:id
router.delete('/:id', async (req, res) => {
  try {
    await productDbPool.execute(`DELETE FROM bunon_categories WHERE id = ?`, [req.params.id]);
    res.json({ ok: true });
  } catch (e: any) {
    console.error('[Admin Categories] Delete error:', e.message);
    res.status(500).json({ ok: false, msg: 'Server error' });
  }
});

export default router;
