import express from 'express';
import { verifyAdmin } from '../../middleware/auth';

import marketingRoutes from './marketing';
import ordersRoutes from './orders';
import statsRoutes from './stats';
import productsRoutes from './products'; // I will create this next
import settingsRoutes from './settings'; // I will create this next
import categoriesRoutes from './categories';
import blogsRoutes from './blogs';

const router = express.Router();

// Apply verifyAdmin middleware to ALL admin routes
router.use(verifyAdmin);

router.use('/marketing', marketingRoutes);
router.use('/orders', ordersRoutes);
router.use('/stats', statsRoutes);
router.use('/products', productsRoutes);
router.use('/settings', settingsRoutes);
router.use('/categories', categoriesRoutes);
router.use('/blogs', blogsRoutes);

export default router;
